import java.util.Scanner;
public class Cau1 {
    public static void main(String[] args) {
        Scanner scanner =new Scanner(System.in);
        System.out.println("nhap ho ten: ");
        String ten = scanner.nextLine();
        System.out.println(" hello " + ten);
        scanner.close();
    }
}