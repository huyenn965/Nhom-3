package bai2;

public class cau2 {

}
